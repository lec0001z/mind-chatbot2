from flask import Flask, render_template, request
import webbrowser
from openai import OpenAI

app = Flask(__name__)
client = OpenAI(api_key="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")

# 감성 공감 함수
def get_empathic_reply(user_input):
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": (
                "너는 감성 챗봇이야. 사용자의 말을 듣고 공감해줘. "
                "그리고 부드럽게 '그런 하루 뒤 지금 기분은 어떤지 알려주실래요?' 같은 말로 이어줘."
            )},
            {"role": "user", "content": user_input}
        ]
    )
    return response.choices[0].message.content

@app.route("/", methods=["GET", "POST"])
def index():
    response = ""
    if request.method == "POST":
        user_input = request.form.get("user_input")
        emotion_choice = request.form.get("emotion")
        if user_input:
            response = get_empathic_reply(user_input)
        elif emotion_choice:
            # 감정에 따라 myNoise 링크 열기
            noise_links = {
                "1": "https://www.youtube.com/watch?v=RA8gajb1KOU",
                "2": "https://www.youtube.com/watch?v=8i7il15SzmM",
                "3": "https://mynoise.net/NoiseMachines/whiteNoiseGenerator.php",
                "4": "https://mynoise.net/NoiseMachines/rainNoiseGenerator.php"
            }
            url = noise_links.get(emotion_choice)
            if url:
                webbrowser.open(url)
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)
