from openai import OpenAI
import webbrowser

# OpenAI 클라이언트 객체 생성
client = OpenAI(api_key="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")  # 너의 API 키로 교체

# 최신 방식에 맞는 GPT 대화 함수
def chat_with_gpt_and_empathize_soft(prompt):
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": (
                    "너는 감성 챗봇이야. 사용자의 말을 듣고 공감해줘. "
                    "그리고 부드럽게 '그럼 지금 기분도 알려주실래요?' 같은 말로 이어줘. "
                    "절대 추가 질문은 하지 마."
                )
            },
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content


# 링크 열기 함수
def open_noise_site(emotion_num):
    links = {
        "1": "https://mynoise.net/NoiseMachines/pinkNoiseGenerator.php",
        "2": "https://mynoise.net/NoiseMachines/brownNoiseGenerator.php",
        "3": "https://mynoise.net/NoiseMachines/whiteNoiseGenerator.php",
        "4": "https://mynoise.net/NoiseMachines/rainNoiseGenerator.php"
    }
    url = links.get(emotion_num)
    if url:
        print(f"🔗 웹 브라우저에서 해당 노이즈 페이지를 엽니다: {url}")
        webbrowser.open(url)
    else:
        print("⚠️ 잘못된 선택입니다.")

# 메인 함수
def main():
    print("안녕하세요! 오늘 하루는 어땠나요?")
    user_input = input("→ 당신: ")

    gpt_reply = chat_with_gpt_and_empathize_soft(user_input)
    print("GPT:", gpt_reply)

    print("\n지금 기분을 숫자로 알려주세요:")
    print("1) 숲속 걷기")
    print("2) 해변 멍때리기")
    print("3) 창밖 보기")
    print("4) 그냥 조용히 있고 싶다")

    choice = input("→ 번호 입력: ")
    open_noise_site(choice)

# 실행
if __name__ == "__main__":
    main()
